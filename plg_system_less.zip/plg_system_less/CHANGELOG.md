## Version 0.8.2 Stable (2015-09-15)
+ Custom version by Jannik Mewes - supports multiple input / output files. Separate by comma.

## Version 0.8.1 Stable (2015-09-15)
+ fix issue #30: less.php v1.7.0.3 not supporting custom formatters, using "classic instead"

## Version 0.8.0 Stable (2015-05-23)
+ Refactor of class loading and fix autoload by @jeffchannell
+ Adding less.php v1.7.0.3 for latest Bootstrap (3.3+) support, supports also older Bootsrap versions

## Version 0.7.5 Stable (2014-10-23)
+ Hide -Select None- option in filelist field. Fixes Issue #24

## Version 0.7.4 Beta (2014-10-20)
+ Support for Bootstrap 3 (switch between lessphp 0.3.8 and 0.4.0) Thanks to @robwent PR #20

## Version 0.7.3 Beta (2013-10-26)
+ fixed bug causing compilation even if cached version is available by @stiplady PR #18
+ updated language fr-FR translation by @lomart, PR #17
+ language file fix by @Bit32, PR #14

## Version 0.7.2 Beta (2013-07-21)
+ improved removeCss mechanism by @piotr-cz PR #11

## Version 0.7.1 Beta
+ new feature: client-side compiler for easier .less debugging, thanks to @piotr-cz (http://piotr.cz)
+ check if lessc already included to avoid conflict with other plugins
+ check if cached less file has correct path, fixes #9
+ backport of mixin classname crash from master repository, fixes #7


## Version 0.7.0 Beta
+ update lessphp to version 0.3.9, thanks to Klipper
+ changed versioning to work with joomla update functions
+ added russian translation, thanks to Pazys
+ added update server for one-click updates from joomla backend
